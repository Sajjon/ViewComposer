// Generated using Sourcery 0.6.1 — https://github.com/krzysztofzablocki/Sourcery
// DO NOT EDIT


extension AutoCasesEnum {
  static let count: Int = 4
  static let allCases: [AutoCasesEnum] = [
    .north,
    .south,
    .east,
    .west
  ]
}
extension AutoCasesHasAssociatedValuesEnum {
  static let count: Int = 2
}
extension AutoCasesOneValueEnum {
  static let count: Int = 1
  static let allCases: [AutoCasesOneValueEnum] = [
    .one
  ]
}
